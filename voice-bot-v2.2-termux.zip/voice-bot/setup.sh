#!/bin/bash
# =============================================
#   VOICE BOT v2.2 — AUTO SETUP SCRIPT
#   Hỗ trợ: Linux · macOS · Termux (Android)
# =============================================

RED='\033[0;31m'
GREEN='\033[0;32m'
YELLOW='\033[1;33m'
CYAN='\033[0;36m'
BOLD='\033[1m'
NC='\033[0m'

SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"

echo ""
echo -e "${CYAN}${BOLD}=================================================${NC}"
echo -e "${CYAN}${BOLD}   🎵  DISCORD VOICE BOT v2.2 — SETUP TOOL  🎵  ${NC}"
echo -e "${CYAN}${BOLD}=================================================${NC}"
echo ""

# ─── BƯỚC 1: Phát hiện nền tảng ───────────────
echo -e "${BOLD}[1/6] Kiểm tra hệ thống...${NC}"

IS_TERMUX=false
IS_ANDROID_SDCARD=false
PLATFORM="Linux"

if [[ -n "$TERMUX_VERSION" ]] || [[ -d "/data/data/com.termux" ]]; then
    IS_TERMUX=true
    PLATFORM="Termux (Android)"
fi

# Phát hiện SDCARD — Android chặn dlopen() native .node từ external storage
case "$SCRIPT_DIR" in
    /storage/*|/sdcard/*|/mnt/sdcard/*)
        IS_ANDROID_SDCARD=true
        ;;
esac

echo -e "     ✅ Nền tảng: ${GREEN}${PLATFORM}${NC}"

# ⛔ SDCARD trên Android không cho load native .node files → di chuyển sang internal storage
if $IS_ANDROID_SDCARD; then
    echo ""
    echo -e "     ${RED}${BOLD}⛔  CẢNH BÁO: Đường dẫn SDCARD phát hiện!${NC}"
    echo -e "     ${RED}   Android chặn load native library từ /storage/ (bảo mật SELinux).${NC}"
    echo -e "     ${YELLOW}   Bot sẽ crash với lỗi ERR_DLOPEN_FAILED khi chạy từ đây.${NC}"
    echo ""
    INTERNAL_DEST="$HOME/voice-bot"
    echo -e "     ${BOLD}Tự động di chuyển sang internal storage:${NC}"
    echo -e "     ${CYAN}${INTERNAL_DEST}${NC}"
    echo ""
    read -p "     Xác nhận di chuyển? (Y/n): " CONFIRM_MOVE
    if [[ "$CONFIRM_MOVE" != "n" ]] && [[ "$CONFIRM_MOVE" != "N" ]]; then
        mkdir -p "$HOME"
        if cp -r "$SCRIPT_DIR" "$INTERNAL_DEST" 2>/dev/null; then
            echo -e "     ${GREEN}✅ Đã copy sang: ${INTERNAL_DEST}${NC}"
            echo ""
            echo -e "     ${BOLD}Chạy lại setup từ vị trí mới:${NC}"
            echo -e "     ${CYAN}cd ${INTERNAL_DEST} && bash setup.sh${NC}"
            echo ""
            exit 0
        else
            echo -e "     ${RED}❌ Copy thất bại — hãy tự copy thủ công:${NC}"
            echo -e "     ${YELLOW}cp -r \"$SCRIPT_DIR\" ~/voice-bot && cd ~/voice-bot && bash setup.sh${NC}"
            exit 1
        fi
    else
        echo -e "     ${YELLOW}⚠️  Tiếp tục từ SDCARD — bot CÓ THỂ bị lỗi khi chạy.${NC}"
        echo -e "     ${YELLOW}   Nếu lỗi ERR_DLOPEN_FAILED, hãy chạy lại từ ~/voice-bot${NC}"
    fi
fi

# ─── BƯỚC 2: Kiểm tra / cài Node.js ──────────
echo ""
echo -e "${BOLD}[2/6] Kiểm tra Node.js...${NC}"
if command -v node &>/dev/null; then
    NODE_VER=$(node --version)
    NODE_MAJOR=$(node --version | sed 's/v\([0-9]*\).*/\1/')
    echo -e "     ✅ Node.js: ${GREEN}${NODE_VER}${NC}"
    if [[ "$NODE_MAJOR" -lt 18 ]]; then
        echo -e "     ${YELLOW}⚠️  Khuyến nghị Node.js >= 18 (hiện tại ${NODE_VER})${NC}"
        if $IS_TERMUX; then
            echo -e "     Cài bằng: ${YELLOW}pkg install nodejs-lts${NC}"
        fi
    fi
else
    echo -e "     ${RED}❌ Node.js chưa được cài!${NC}"
    if $IS_TERMUX; then
        echo -e "     Đang thử cài qua pkg..."
        pkg install nodejs-lts -y
    else
        echo -e "     Tải tại: ${CYAN}https://nodejs.org${NC}"
        if [[ "$PLATFORM" == "Linux" ]]; then
            echo -e "     Hoặc: ${YELLOW}curl -fsSL https://deb.nodesource.com/setup_20.x | sudo -E bash - && sudo apt install -y nodejs${NC}"
        fi
    fi
    read -p "Nhấn Enter sau khi cài xong Node.js..." _
    if ! command -v node &>/dev/null; then
        echo -e "${RED}Vẫn chưa tìm thấy Node.js. Thoát.${NC}"; exit 1
    fi
fi

# ─── BƯỚC 3: Kiểm tra / cài Python & yt-dlp ──
echo ""
echo -e "${BOLD}[3/6] Kiểm tra Python & yt-dlp...${NC}"

PY_CMD=""
for cmd in python3 python; do
    if command -v "$cmd" &>/dev/null; then PY_CMD="$cmd"; break; fi
done

if [[ -z "$PY_CMD" ]]; then
    echo -e "     ${YELLOW}⚠️  Python không tìm thấy${NC}"
    if $IS_TERMUX; then
        echo -e "     Đang cài Python qua pkg..."
        pkg install python -y
        PY_CMD="python"
    fi
fi

if [[ -n "$PY_CMD" ]]; then
    echo -e "     ✅ Python: ${GREEN}$($PY_CMD --version 2>&1)${NC}"
    if $PY_CMD -m yt_dlp --version &>/dev/null 2>&1; then
        echo -e "     ✅ yt-dlp: ${GREEN}$($PY_CMD -m yt_dlp --version 2>&1 | head -1)${NC}"
    else
        echo -e "     ⏳ Đang cài yt-dlp..."
        if $IS_TERMUX; then
            pip install yt-dlp -q || $PY_CMD -m pip install yt-dlp -q
        else
            $PY_CMD -m pip install yt-dlp -q
        fi
        $PY_CMD -m yt_dlp --version &>/dev/null && \
            echo -e "     ✅ yt-dlp đã cài xong!" || \
            echo -e "     ${YELLOW}⚠️  Không cài được yt-dlp. Thử: pip install yt-dlp${NC}"
    fi
fi

# ─── BƯỚC 4: Kiểm tra / cài ffmpeg ───────────
echo ""
echo -e "${BOLD}[4/6] Kiểm tra ffmpeg...${NC}"
if command -v ffmpeg &>/dev/null; then
    FF_VER=$(ffmpeg -version 2>&1 | head -1 | awk '{print $3}')
    echo -e "     ✅ ffmpeg: ${GREEN}${FF_VER}${NC}"
else
    if $IS_TERMUX; then
        echo -e "     ⏳ Đang cài ffmpeg qua pkg..."
        pkg install ffmpeg -y
        command -v ffmpeg &>/dev/null && \
            echo -e "     ✅ ffmpeg đã cài xong!" || \
            echo -e "     ${YELLOW}⚠️  Không cài được ffmpeg${NC}"
    else
        echo -e "     ${YELLOW}⚠️  ffmpeg không tìm thấy — sẽ dùng ffmpeg-static${NC}"
        if [[ "$PLATFORM" == "Linux" ]]; then
            echo -e "     Cài bằng: ${YELLOW}sudo apt install ffmpeg${NC}"
        elif [[ "$PLATFORM" == "macOS" ]]; then
            echo -e "     Cài bằng: ${YELLOW}brew install ffmpeg${NC}"
        fi
    fi
fi

# ─── BƯỚC 5: Cài npm packages ─────────────────
echo ""
echo -e "${BOLD}[5/6] Cài đặt npm packages...${NC}"
cd "$SCRIPT_DIR" || exit 1

# Trên Termux: luôn dùng --ignore-scripts vì ARM không build được native modules
NPM_FLAGS="--no-fund --no-audit"
if $IS_TERMUX; then
    NPM_FLAGS="$NPM_FLAGS --ignore-scripts"
    echo -e "     ℹ️  Termux: dùng --ignore-scripts (bỏ qua native build)"
fi
if $IS_ANDROID_SDCARD; then
    NPM_FLAGS="$NPM_FLAGS --no-bin-links"
    echo -e "     ℹ️  Dùng --no-bin-links (SDCARD không hỗ trợ symlink)"
fi

echo -e "     ⏳ Đang chạy npm install... (có thể mất 1-5 phút)"
if npm install $NPM_FLAGS 2>&1; then
    echo -e "     ✅ Tất cả packages đã cài xong!"
else
    echo -e "     ${YELLOW}⚠️  Lỗi khi cài tất cả — thử cài từng package...${NC}"
    BASE_PACKAGES=(
        "discord.js-selfbot-v13"
        "@discordjs/voice"
        "play-dl"
        "prism-media"
        "libsodium-wrappers"
        "ffmpeg-static"
        "@distube/ytdl-core"
        "youtubei.js"
        "ytsr"
    )
    FAILED=()
    for pkg in "${BASE_PACKAGES[@]}"; do
        printf "     Cài %-45s" "$pkg..."
        if npm install "$pkg" $NPM_FLAGS --silent 2>/dev/null; then
            echo -e "${GREEN}✅${NC}"
        else
            echo -e "${RED}❌${NC}"
            FAILED+=("$pkg")
        fi
    done
    if [[ ${#FAILED[@]} -gt 0 ]]; then
        echo -e "     ${YELLOW}Packages cài thất bại: ${FAILED[*]}${NC}"
    else
        echo -e "     ✅ Đã cài xong tất cả packages riêng lẻ!"
    fi
fi

# opusscript fallback nếu @discordjs/opus lỗi (thường gặp trên ARM)
if ! node -e "require('@discordjs/opus')" 2>/dev/null; then
    echo -e "     ⏳ @discordjs/opus lỗi — cài opusscript thay thế..."
    npm install opusscript $NPM_FLAGS --silent 2>/dev/null && \
        echo -e "     ✅ opusscript đã cài!" || true
fi

# ─── CÀI RIÊNG: @dank074/discord-video-stream ─
echo ""
echo -e "     ${BOLD}⏳ Cài @dank074/discord-video-stream (stream lib)...${NC}"
if $IS_TERMUX; then
    echo -e "     ℹ️  Termux: dùng --ignore-scripts bắt buộc"
fi

install_stream_lib() {
    local ver="$1" extra_flags="$2"
    npm install "@dank074/discord-video-stream@${ver}" $NPM_FLAGS $extra_flags --silent 2>/dev/null
}

test_stream_lib() {
    node --input-type=module <<'EOF' 2>/dev/null
import '@dank074/discord-video-stream';
EOF
}

test_stream_lib_verbose() {
    node --input-type=module <<'EOF'
import '@dank074/discord-video-stream';
console.log('OK');
EOF
}

# Thứ tự thử: v6 → v6 --ignore-scripts → v5 --ignore-scripts → v4 --ignore-scripts
STREAM_OK=false
for try_spec in "6:" "6:--ignore-scripts" "5:--ignore-scripts" "4:--ignore-scripts"; do
    ver="${try_spec%%:*}"
    flags="${try_spec##*:}"
    printf "     Thử v%s %s ... " "$ver" "$flags"
    if install_stream_lib "$ver" "$flags"; then
        if test_stream_lib; then
            echo -e "${GREEN}✅ v${ver} OK!${NC}"
            STREAM_OK=true
            break
        else
            echo -e "${YELLOW}⚠️  import lỗi${NC}"
        fi
    else
        echo -e "${RED}❌ cài lỗi${NC}"
    fi
done

if ! $STREAM_OK; then
    echo ""
    echo -e "     ${RED}❌ Không cài được stream lib.${NC}"
    echo -e "     ${YELLOW}Lỗi thực tế:${NC}"
    test_stream_lib_verbose 2>&1 | sed 's/^/       /'
    echo ""
    echo -e "     ${CYAN}Bot vẫn chạy được — chỉ lệnh !vstream bị ảnh hưởng.${NC}"
    echo -e "     ${CYAN}Dùng !streamtest trong Discord để xem lỗi chi tiết.${NC}"
fi

# ─── BƯỚC 6: Cài đặt Token ────────────────────
echo ""
echo -e "${BOLD}[6/6] Cài đặt Token Discord...${NC}"

if [[ -f ".env" ]] && grep -q "DISCORD_TOKEN=" ".env" && ! grep -q "TOKEN_CỦA_BẠN" ".env"; then
    echo -e "     ✅ Token đã được cài (file .env tồn tại)"
    echo -e "     ${YELLOW}Bỏ qua — sửa file .env nếu muốn đổi token${NC}"
else
    echo ""
    echo -e "     ${BOLD}Điền Discord User Token để bot hoạt động:${NC}"
    echo -e "     ${CYAN}(Lấy token: F12 → Network → Filter 'api' → Header 'authorization')${NC}"
    echo ""
    read -p "     Dán token vào đây (Enter để bỏ qua): " USER_TOKEN
    if [[ -n "$USER_TOKEN" ]] && [[ "$USER_TOKEN" != "TOKEN_CỦA_BẠN" ]]; then
        echo "DISCORD_TOKEN=${USER_TOKEN}" > ".env"
        echo "ALLOWED_USER_ID=1513846719660556399" >> ".env"
        echo -e "     ✅ Đã lưu token vào ${GREEN}.env${NC}"
    else
        echo -e "     ${YELLOW}⚠️  Bỏ qua — sửa .env hoặc index.js thủ công.${NC}"
    fi
fi

# ─── TỔNG KẾT ─────────────────────────────────
echo ""
echo -e "${CYAN}${BOLD}=================================================${NC}"
echo -e "${GREEN}${BOLD}   ✅  Cài đặt hoàn tất!${NC}"
echo -e "${CYAN}${BOLD}=================================================${NC}"
echo ""
echo -e " Để chạy bot:"
echo -e "   ${BOLD}node index.js${NC}"
echo ""
echo -e " Chạy nền (Linux/macOS/Termux):"
echo -e "   ${BOLD}nohup node index.js > bot.log 2>&1 &${NC}"
echo ""
if $IS_TERMUX; then
    echo -e " Termux: giữ bot chạy khi tắt màn hình:"
    echo -e "   ${BOLD}termux-wake-lock${NC}  (giữ CPU không ngủ)"
    echo ""
fi
echo -e " Gõ ${BOLD}!help${NC} trong Discord để xem danh sách lệnh"
echo ""
