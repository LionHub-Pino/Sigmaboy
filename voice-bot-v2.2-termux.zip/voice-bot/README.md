# 🎵 Discord Voice Bot v2.2

Selfbot Discord phát nhạc & stream video trong voice channel.

---

## 🚀 Cài đặt nhanh

### Linux / macOS
```bash
cd voice-bot
bash setup.sh
```

### Windows
```
Vào thư mục voice-bot → Double-click setup.bat
```

Script tự động:
- ✅ Kiểm tra Node.js, Python, ffmpeg
- ✅ Cài yt-dlp nếu chưa có
- ✅ Chạy `npm install`
- ✅ Hỏi và lưu token vào file `.env`

---

## ▶️ Chạy bot

```bash
cd voice-bot
node index.js
```

---

## 🔑 YouTube Cookie (Quan trọng!)

YouTube chặn các server cloud (Replit, VPS, v.v.) — cần cookie để phát nhạc YT.

### Cách lấy cookie (chọn 1 trong 2):

**Cách 1 — Browser Console (nhanh nhất):**
1. Vào https://www.youtube.com và **đăng nhập**
2. Nhấn **F12** → tab **Console**
3. Gõ lệnh: `document.cookie`
4. Copy toàn bộ kết quả (dòng dài)
5. Trong Discord, gõ: `!setcookie <dán vào đây>`

**Cách 2 — Extension (bền hơn, khuyên dùng):**
1. Cài extension **"Get cookies.txt LOCALLY"** trên Chrome/Edge
2. Vào youtube.com (đã đăng nhập) → click extension → **Export**
3. Upload file `cookies.txt` vào thư mục `voice-bot/`
4. Đổi tên thành `.yt_cookie` (có dấu chấm ở đầu)

**Kiểm tra trạng thái cookie:**
```
!cookie
```

**Lưu ý:**
- Cookie lưu vào file `.yt_cookie` (gitignored, an toàn)
- Cookie hết hạn sau vài tuần → cần set lại
- `!setcookie clear` để xóa cookie

---

## 📋 Danh sách lệnh

### 🎵 Phát nhạc
| Lệnh | Mô tả |
|------|-------|
| `!play <tên/link/playlist>` | Phát nhạc YouTube hoặc file |
| `!playtop <tên/link>` | Thêm lên đầu hàng đợi |
| `!search <từ khóa>` | Tìm kiếm (8 kết quả) |
| `!pick <số>` | Phát từ kết quả tìm kiếm |
| `!addall` | Thêm tất cả kết quả vào queue |
| `!replay` | Phát lại bài hiện tại |
| `!skip [số]` | Bỏ qua 1 hoặc nhiều bài |
| `!stop` | Dừng nhạc + xóa queue |
| `!pause` / `!resume` | Tạm dừng / Tiếp tục |
| `!loop` | Bật/Tắt lặp bài đang phát |
| `!autoplay` | Tự phát bài tương tự khi hết queue |
| `!volume <0-200>` | Chỉnh âm lượng |
| `!np` | Bài đang phát + trạng thái |

### 📋 Hàng đợi
| Lệnh | Mô tả |
|------|-------|
| `!queue [trang]` | Xem danh sách |
| `!move <từ> <đến>` | Di chuyển vị trí bài |
| `!remove <số>` | Xóa bài khỏi hàng đợi |
| `!shuffle` | Trộn ngẫu nhiên |
| `!clear` | Xóa hết hàng đợi |
| `!history` | Lịch sử phát gần đây |

### 📺 Stream video (Go Live)
| Lệnh | Mô tả |
|------|-------|
| `!vstream <link> [360\|480\|720\|1080]` | Stream video qua Go Live |
| `!stopstream` | Dừng stream |

**Hỗ trợ:** YouTube, Twitch, TikTok, Instagram, Facebook, Twitter/X, Reddit, Bilibili, Vimeo, Dailymotion, Streamable, Medal.tv, link .mp4/.webm trực tiếp

### 🔑 Cookie
| Lệnh | Mô tả |
|------|-------|
| `!cookie` | Xem trạng thái + hướng dẫn lấy cookie |
| `!setcookie <chuỗi>` | Set YouTube cookie |
| `!setcookie clear` | Xóa cookie |

### 🔧 Tiện ích
| Lệnh | Mô tả |
|------|-------|
| `!join` / `!leave` | Vào / Rời phòng voice |
| `!ping` | Kiểm tra độ trễ |
| `!uptime` | Thời gian bot đã chạy |
| `!update` | Cập nhật yt-dlp |

---

## ⚙️ Cấu hình .env

```env
DISCORD_TOKEN=token_của_bạn_ở_đây
ALLOWED_USER_ID=id_discord_của_bạn
PREFIX=!
YT_COOKIE=cookie_string_tùy_chọn
```

`YT_COOKIE` có thể set qua lệnh `!setcookie` trong Discord thay vì điền thủ công vào đây.

---

## 🛠️ Tech Stack

- **discord.js-selfbot-v13** — Discord selfbot
- **@discordjs/voice** — Voice/audio streaming
- **@dank074/discord-video-stream** — Go Live video streaming
- **play-dl** — YouTube audio streaming (không cần download file)
- **yt-dlp** — Video download cho !vstream và playlist
- **ffmpeg** — Video encoding

---

## ⚠️ Lưu ý

- Đây là **selfbot** — vi phạm ToS Discord. Dùng trên account phụ.
- Cookie YouTube hết hạn sau vài tuần → cần set lại bằng `!setcookie`.
- `!vstream` với YouTube cần cookie để tải video.
