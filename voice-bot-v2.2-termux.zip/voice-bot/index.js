const { Client } = require('discord.js-selfbot-v13');
const {
    joinVoiceChannel,
    createAudioPlayer,
    createAudioResource,
    getVoiceConnection,
    AudioPlayerStatus,
    StreamType,
} = require('@discordjs/voice');
// @dank074/discord-video-stream là ESM-only → dùng dynamic import()
let _streamLib = null;
let _streamer  = null;
let _currentStreamCmd  = null;   // ffmpeg FluentCommand đang chạy (để !vstop kill)
let _streamChannel     = null;   // voice channel đang stream (để rejoin sau)
async function getStreamLib() {
    if (!_streamLib) {
        try {
            _streamLib = await import('@dank074/discord-video-stream');
        } catch (e) {
            // Build full error chain để dễ debug trên mọi nền tảng
            const parts = [];
            let cur = e;
            while (cur) {
                parts.push(cur.message || String(cur));
                cur = cur.cause;
            }
            const fullMsg = parts.join('\n  caused by: ');
            console.error('[STREAM LIB] Import failed:', fullMsg);
            throw new Error(
                `❌ Không load được @dank074/discord-video-stream\n` +
                `Lỗi: ${fullMsg}\n\n` +
                `Termux fix:\n` +
                `  cd ~/voice-bot\n` +
                `  rm -rf node_modules\n` +
                `  npm install --ignore-scripts\n` +
                `  npm install @dank074/discord-video-stream --ignore-scripts`
            );
        }
    }
    return _streamLib;
}
async function getStreamer() {
    if (!_streamer) {
        const lib = await getStreamLib();
        _streamer = new lib.Streamer(client);
    }
    return _streamer;
}
const { exec, execSync, spawn } = require('child_process');
const fs = require('fs');
const path = require('path');
const os = require('os');
const play = require('play-dl');

// =============================================
//   AUTO-DETECT FFMPEG (Termux ARM support)
// =============================================
function detectFfmpeg() {
    // 1. Ưu tiên system ffmpeg (bắt buộc trên Termux/ARM)
    try { execSync('ffmpeg -version', { stdio: 'ignore', timeout: 3000 }); return 'ffmpeg'; } catch (_) {}
    // 2. Fallback: ffmpeg-static (x86_64 Linux/macOS)
    try { const p = require('ffmpeg-static'); if (p && fs.existsSync(p)) return p; } catch (_) {}
    return null;
}
const FFMPEG_PATH = detectFfmpeg();
if (FFMPEG_PATH && FFMPEG_PATH !== 'ffmpeg') process.env.FFMPEG_PATH = FFMPEG_PATH;
// fluent-ffmpeg cũng đọc FFMPEG_PATH — set trước khi load stream lib
if (FFMPEG_PATH) {
    try { const ff = require('fluent-ffmpeg'); ff.setFfmpegPath(FFMPEG_PATH); } catch (_) {}
}

// =============================================
//   AUTO-DETECT YT-DLP (Termux / Linux / pip)
// =============================================
function detectYtDlp() {
    // 1. Binary yt-dlp trực tiếp (Termux pkg / pip install yt-dlp với --break-system)
    try { execSync('yt-dlp --version', { stdio: 'ignore', timeout: 5000 }); return { cmd: 'yt-dlp', args: [] }; } catch (_) {}
    // 2. python3 -m yt_dlp
    try { execSync('python3 -m yt_dlp --version', { stdio: 'ignore', timeout: 5000 }); return { cmd: 'python3', args: ['-m', 'yt_dlp'] }; } catch (_) {}
    // 3. python -m yt_dlp
    try { execSync('python -m yt_dlp --version', { stdio: 'ignore', timeout: 5000 }); return { cmd: 'python', args: ['-m', 'yt_dlp'] }; } catch (_) {}
    return null;
}
const YTDLP = detectYtDlp();

// Thư mục temp: dùng os.tmpdir() để tránh SDCARD trên Android
const TMP_DIR = (() => {
    const t = os.tmpdir();
    return t && fs.existsSync(t) ? t : __dirname;
})();

// =============================================
//                 CẤU HÌNH
// =============================================
const USER_TOKEN  = 'OTE1NTE2ODM3ODI2MDE1Mjgy.GHoMnv.NveoszYnjKNr4f4RfpT-jaQwKmtUvcxpAZP0yM';
const ALLOWED_ID  = '1513846719660556399';
const PREFIX      = '!';

// File lưu YouTube cookie (cạnh index.js)
const YT_COOKIE_FILE     = path.join(__dirname, '.yt_cookie');
const YT_COOKIES_TXT     = path.join(__dirname, 'cookies.txt');
// Cookie string dùng cho play-dl
let ytCookieString = process.env.YT_COOKIE || '';
if (!ytCookieString && fs.existsSync(YT_COOKIE_FILE)) {
    try { ytCookieString = fs.readFileSync(YT_COOKIE_FILE, 'utf8').trim(); } catch (_) {}
}
// =============================================


const client = new Client({ checkUpdate: false });

// Khởi tạo play-dl với cookie nếu có
async function initPlayDl() {
    if (ytCookieString) {
        try {
            await play.setToken({ youtube: { cookie: ytCookieString } });
            console.log('✅ YouTube cookie đã được load!');
        } catch (e) {
            console.warn('⚠️ Cookie không hợp lệ hoặc hết hạn:', e.message);
        }
    } else {
        console.log('⚠️ Chưa có YouTube cookie — dùng !setcookie để set nếu cần phát nhạc YT');
    }
}
initPlayDl();

// ── AUDIO PLAYER ──────────────────────────────
const player = createAudioPlayer({ behaviors: { noSubscriber: 'pause' } });
player.currentFile  = null;
player.currentTitle = null;
player.currentUrl   = null;
player.loopMode     = false;
player.volume       = 100;
player.startedAt    = null;

// ── STATE ─────────────────────────────────────
const queue       = [];    // [{ title, url, duration, type, file? }]
const history     = [];    // last 10 played
let   isPlaying   = false;
let   isStreaming  = false;
let   autoplay    = false;
let   lastSearchResults  = [];
let   lastVSearchResults = [];   // kết quả !vsearch (video stream)
const videoQueue         = [];   // [{ url, q, title }] — hàng đợi video stream

// =============================================
//            HELPER FUNCTIONS
// =============================================

function cleanupFile(filePath) {
    if (filePath && fs.existsSync(filePath)) {
        try { fs.unlinkSync(filePath); }
        catch (_) {}
    }
}

function getOrJoinVoice(message) {
    let channel = message.member?.voice?.channel;
    if (!channel) {
        for (const guild of client.guilds.cache.values()) {
            const m = guild.members.cache.get(ALLOWED_ID);
            if (m?.voice?.channel) { channel = m.voice.channel; break; }
        }
    }
    if (!channel) return null;

    let connection = getVoiceConnection(channel.guild.id);
    if (!connection) {
        connection = joinVoiceChannel({
            channelId: channel.id,
            guildId: channel.guild.id,
            adapterCreator: channel.guild.voiceAdapterCreator,
            selfMute: false,
            selfDeaf: false,
        });
    }
    connection.subscribe(player);
    return { connection, channel };
}

function secToTime(sec) {
    if (!sec || isNaN(sec)) return '?:??';
    const h = Math.floor(sec / 3600);
    const m = Math.floor((sec % 3600) / 60);
    const s = Math.floor(sec % 60);
    return h > 0
        ? `${h}:${m.toString().padStart(2,'0')}:${s.toString().padStart(2,'0')}`
        : `${m}:${s.toString().padStart(2,'0')}`;
}

function elapsed() {
    if (!player.startedAt) return '';
    const secs = Math.floor((Date.now() - player.startedAt) / 1000);
    return secToTime(secs);
}

function addHistory(item) {
    history.unshift({ ...item, playedAt: new Date().toLocaleTimeString('vi-VN') });
    if (history.length > 10) history.pop();
}

function buildQueueMsg(page = 0) {
    if (queue.length === 0) return '📭 Hàng đợi trống!';
    const PER = 10;
    const total = Math.ceil(queue.length / PER);
    const slice = queue.slice(page * PER, page * PER + PER);
    let msg = `📋 **Hàng đợi** (${queue.length} bài | trang ${page+1}/${total})\n`;
    msg += `🔁 Lặp: ${player.loopMode?'✅':'❌'}  |  🔊 Âm lượng: ${player.volume}%  |  ✨ Autoplay: ${autoplay?'✅':'❌'}\n\n`;
    slice.forEach((item, i) => {
        const n = i + page * PER;
        const icon = n === 0 && isPlaying ? '▶️' : `\`${n+1}.\``;
        msg += `${icon} **${item.title}**${item.duration ? ` [${item.duration}]` : ''}\n`;
    });
    return msg;
}

// Các site yt-dlp hỗ trợ download video
const YTDLP_SITES = [
    'youtube.com', 'youtu.be',
    'twitch.tv', 'clips.twitch.tv',
    'tiktok.com',
    'instagram.com',
    'facebook.com', 'fb.watch',
    'twitter.com', 'x.com', 't.co',
    'reddit.com', 'v.redd.it',
    'bilibili.com',
    'vimeo.com',
    'dailymotion.com',
    'streamable.com',
    'medal.tv', 'clips.medal.tv',
];

const DIRECT_VIDEO_EXT = ['.mp4', '.webm', '.mkv', '.mov', '.avi', '.flv', '.ts', '.m4v', '.mpg', '.mpeg'];

function isYouTubeUrl(str) {
    return str && (str.includes('youtube.com') || str.includes('youtu.be'));
}

function isDirectVideoUrl(str) {
    if (!str) return false;
    try {
        const u = new URL(str);
        return DIRECT_VIDEO_EXT.some(ext => u.pathname.toLowerCase().endsWith(ext));
    } catch { return false; }
}

function isPlaylistUrl(str) {
    return str && (str.includes('list=') || str.includes('/playlist'));
}

// Helper: build cookie args cho yt-dlp
function ytdlpCookieArgs() {
    // Ưu tiên file cookies.txt Netscape (đáng tin hơn)
    if (fs.existsSync(YT_COOKIES_TXT)) return `--cookies "${YT_COOKIES_TXT}"`;
    if (!ytCookieString) return '';
    const safeVal = ytCookieString.replace(/\n/g, ' ').trim();
    return `--add-headers "Cookie:${safeVal}"`;
}

// =============================================
//    PLAY NEXT — trái tim của bot
// =============================================
async function playNext(message) {
    if (queue.length === 0) {
        isPlaying = false;
        player.currentTitle = null;
        player.startedAt    = null;
        // Autoplay: tìm bài tương tự bài cuối
        if (autoplay && history.length > 0) {
            message.channel.send('🎲 Autoplay — đang tìm bài tiếp theo...');
            try {
                const seed    = history[0].title;
                const results = await play.search(seed + ' lyrics', { limit: 8, source: { youtube: 'video' } });
                const pick    = results.find(v => !history.some(h => h.url === v.url));
                if (pick) {
                    queue.push({ title: pick.title, url: pick.url, duration: pick.durationRaw, type: 'youtube' });
                    return playNext(message);
                }
            } catch (_) {}
        }
        return;
    }

    const item = queue[0];
    isPlaying = true;

    if (item.type === 'youtube') {
        // Dùng play-dl để stream trực tiếp — không cần download file
        message.channel.send(`⏳ Đang buffer **${item.title}**...`);
        try {
            const stream   = await play.stream(item.url, { quality: 0 });
            const resource = createAudioResource(stream.stream, {
                inputType: stream.type,
                inlineVolume: true,
            });
            resource.volume?.setVolumeLogarithmic(player.volume / 100);
            player.currentFile  = null;  // không có file tạm
            player.currentTitle = item.title;
            player.currentUrl   = item.url;
            player.startedAt    = Date.now();
            addHistory(item);
            player.play(resource);
            message.channel.send(
                `🎵 Đang phát: **${item.title}**` +
                (item.duration ? ` [${item.duration}]` : '') +
                (queue.length > 1 ? `\n📋 Còn ${queue.length - 1} bài trong hàng đợi` : '')
            );
        } catch (e) {
            const isAuthErr = /sign in|confirm|bot|login/i.test(e.message || '');
            if (isAuthErr) {
                message.channel.send(
                    `🔴 YouTube yêu cầu xác thực!\n` +
                    `> Dùng \`!setcookie <cookie_string>\` để đăng nhập.\n` +
                    `> Gõ \`!cookie\` để xem hướng dẫn lấy cookie.`
                );
            } else {
                message.channel.send(`🔴 Lỗi tải **${item.title}** — ${e.message?.slice(0,120)}`);
            }
            queue.shift();
            return playNext(message);
        }

    } else {
        // URL trực tiếp (file đính kèm, link mp3, v.v.)
        try {
            const resource = createAudioResource(item.url, {
                inputType: StreamType.Arbitrary,
                inlineVolume: true,
            });
            resource.volume?.setVolumeLogarithmic(player.volume / 100);
            player.currentTitle = item.title;
            player.currentUrl   = item.url;
            player.startedAt    = Date.now();
            addHistory(item);
            player.play(resource);
            message.channel.send(`🎵 Đang phát: **${item.title}**`);
        } catch (e) {
            message.channel.send(`🔴 Lỗi: ${e.message}`);
            queue.shift();
            playNext(message);
        }
    }
}

// =============================================
//            PLAYER EVENTS
// =============================================

player.on(AudioPlayerStatus.Idle, () => {
    const old = player.currentFile;
    if (!player.loopMode) {
        cleanupFile(old);
        player.currentFile = null;
        queue.shift();
    } else {
        cleanupFile(old);
        player.currentFile = null;
    }
    if (global._lastMsg) playNext(global._lastMsg);
});

// =============================================
//   runVStream — logic stream dùng chung
// =============================================
async function runVStream(message, url, q) {
    let channel = message.member?.voice?.channel;
    if (!channel) {
        for (const guild of client.guilds.cache.values()) {
            const m = guild.members.cache.get(ALLOWED_ID);
            if (m?.voice?.channel) { channel = m.voice.channel; break; }
        }
    }
    if (!channel) return message.reply('❌ Vào phòng voice trước!');

    if (isStreaming) return message.reply('⚠️ Đang có stream khác chạy! Dùng `!vstop` để dừng trước.');

    const qNum        = parseInt(q);
    const bitrateVideo    = qNum >= 1080 ? 4000 : qNum >= 720 ? 2500 : qNum >= 480 ? 1500 : 800;
    const bitrateVideoMax = qNum >= 1080 ? 5500 : qNum >= 720 ? 3500 : qNum >= 480 ? 2000 : 1200;

    async function doStream(inputPath, isTemp) {
        try {
            console.log('[STREAM] doStream start:', inputPath);
            const lib      = await getStreamLib();
            const streamer = await getStreamer();
            const { prepareStream, playStream, Encoders, Utils } = lib;

            player.stop(true);
            const existingConn = getVoiceConnection(channel.guild.id);
            if (existingConn) {
                console.log('[STREAM] destroying existing @discordjs/voice connection');
                existingConn.destroy();
                await new Promise(r => setTimeout(r, 800));
            }

            _streamChannel = channel;
            console.log('[STREAM] joinVoice guild=%s channel=%s', channel.guild.id, channel.id);
            await streamer.joinVoice(channel.guild.id, channel.id);
            console.log('[STREAM] joinVoice OK');

            const encoder = Encoders.software({ x264: { preset: 'superfast' } });
            const { command: ffmpegCmd, output } = prepareStream(inputPath, {
                encoder,
                height: qNum,
                frameRate: 30,
                bitrateVideo,
                bitrateVideoMax,
                bitrateAudio: 320,
                videoCodec: Utils.normalizeVideoCodec('H264'),
            });

            ffmpegCmd.audioFilters('volume=2');
            _currentStreamCmd = ffmpegCmd;
            ffmpegCmd.on('error', e => console.error('[STREAM ffmpeg]', e.message));
            ffmpegCmd.on('start', cmd => console.log('[STREAM ffmpeg] start:', cmd));
            message.channel.send(`▶️ Bắt đầu stream **${q}p**! (Nhấn **Go Live** trong kênh để xem)`);

            const afterStream = async (stopped = false) => {
                isStreaming = false;
                _currentStreamCmd = null;
                if (isTemp) cleanupFile(inputPath);
                try { await streamer.leaveVoice(); } catch (_) {}
                await new Promise(r => setTimeout(r, 600));
                try {
                    const vc = joinVoiceChannel({
                        channelId: _streamChannel.id,
                        guildId: _streamChannel.guild.id,
                        adapterCreator: _streamChannel.guild.voiceAdapterCreator,
                        selfMute: false,
                        selfDeaf: false,
                    });
                    vc.subscribe(player);
                    console.log('[STREAM] rejoined voice after stream');
                } catch (e) { console.warn('[STREAM] rejoin failed:', e.message); }
                _streamChannel = null;
                if (stopped) return;
                // Auto-play video tiếp theo trong hàng đợi
                if (videoQueue.length > 0) {
                    const next = videoQueue.shift();
                    message.channel.send(`⏭️ Tự phát tiếp: **${next.title || next.url}** (${next.q}p) — còn ${videoQueue.length} video trong queue`);
                    runVStream(message, next.url, next.q);
                } else {
                    message.channel.send('✅ Stream kết thúc! Bot đã rejoin voice.');
                }
            };

            playStream(output, streamer, { type: 'go-live' })
                .then(() => { console.log('[STREAM] ended normally'); afterStream(false); })
                .catch(e => {
                    console.error('[STREAM] playStream error:', e?.message);
                    afterStream(true);
                    if (e?.message !== 'Stream stopped')
                        message.channel.send(`🔴 Lỗi stream: ${e.message}`);
                });
        } catch (se) {
            console.error('[STREAM] catch error:', se?.message, se?.stack);
            isStreaming = false;
            if (isTemp) cleanupFile(inputPath);
            message.channel.send(`🔴 Lỗi khởi động stream: ${se.message}`);
        }
    }

    isStreaming = true;

    if (isDirectVideoUrl(url)) {
        message.channel.send(`📺 Đang stream file video trực tiếp (${q}p)...`);
        await doStream(url, false);
        return;
    }

    const siteName = (() => { try { return new URL(url).hostname.replace('www.',''); } catch { return 'URL'; } })();
    message.channel.send(`📺 Đang tải video từ **${siteName}** (${q}p)...`);

    if (!YTDLP) {
        isStreaming = false;
        return message.channel.send('❌ Không tìm thấy yt-dlp! Chạy: `pip install yt-dlp` (hoặc `pkg install yt-dlp` trên Termux)');
    }

    const outVideo = path.join(TMP_DIR, `stream_${Date.now()}.mp4`);
    const dlArgs = [
        ...YTDLP.args,
        '-f', `best[height<=${q}][protocol=m3u8_native]/best[height<=${q}][ext=mp4]/best[height<=${q}]/best`,
        '--merge-output-format', 'mp4',
        '--no-playlist',
        '--newline',
        '--js-runtimes', 'node',
        '--extractor-args', 'youtube:player_client=web,default',
        '-o', outVideo,
    ];
    if (fs.existsSync(YT_COOKIES_TXT)) dlArgs.push('--cookies', YT_COOKIES_TXT);
    dlArgs.push(url);

    console.log(`[YTDLP] cmd: ${YTDLP.cmd} | start: ${url}`);
    const dlProc = spawn(YTDLP.cmd, dlArgs);
    let stderrBuf = '';
    dlProc.stdout.on('data', d => { const l = d.toString().trim(); if (l) console.log('[YTDLP]', l); });
    dlProc.stderr.on('data', d => { const l = d.toString().trim(); if (l) { console.error('[YTDLP ERR]', l); stderrBuf += l + '\n'; } });
    dlProc.on('close', async (code) => {
        if (code !== 0 || !fs.existsSync(outVideo)) {
            isStreaming = false;
            cleanupFile(outVideo);
            const isAuth    = /sign in|confirm your age|bot|login|age.restricted/i.test(stderrBuf);
            const isGeo     = /not available in your country|geo.?restrict/i.test(stderrBuf);
            const isPrivate = /private video|members.only|unavailable/i.test(stderrBuf);
            if (isAuth) {
                const hint = isYouTubeUrl(url) ? `\n> Dùng \`!setcookie <cookie>\` để đăng nhập.` : '';
                return message.channel.send(`🔴 Video yêu cầu xác thực!${hint}`);
            }
            if (isGeo)     return message.channel.send('🔴 Video bị chặn theo vùng (geo-restricted).');
            if (isPrivate) return message.channel.send('🔴 Video riêng tư hoặc không còn tồn tại.');
            const lastErr = stderrBuf.split('\n').filter(Boolean).pop()?.slice(0, 150) || '';
            return message.channel.send(
                `🔴 Không tải được video từ **${siteName}**!\n> \`${lastErr}\`\nThử: \`!vstream ${url} 480\``
            );
        }
        console.log(`[YTDLP] done: ${outVideo}`);
        await doStream(outVideo, true);
    });
}

// =============================================
//          MESSAGE EVENT — XỬ LÝ LỆNH
// =============================================

client.on('messageCreate', async (message) => {
    if (message.author.id !== ALLOWED_ID) return;
    if (!message.content?.startsWith(PREFIX)) return;

    global._lastMsg = message;

    const parts   = message.content.trim().slice(PREFIX.length).split(/ +/);
    const command = parts.shift().toLowerCase();
    const args    = parts;

    // ── !join ─────────────────────────────────────
    if (command === 'join') {
        const res = getOrJoinVoice(message);
        if (!res) return message.reply('❌ Vào phòng voice trước sếp ơi!');
        return message.reply(`📥 Đã vào **${res.channel.name}** (${res.channel.guild.name})`);
    }

    // ── !leave / !dc ──────────────────────────────
    if (command === 'leave' || command === 'dc') {
        const res = getOrJoinVoice(message);
        if (!res) return message.reply('❌ Bot chưa ở phòng nào!');
        player.stop();
        cleanupFile(player.currentFile);
        player.currentFile = null;
        queue.length = 0;
        isPlaying = false;
        if (isStreaming) { getStreamer().then(s => s.stopStream()); isStreaming = false; }
        res.connection.destroy();
        return message.reply('📤 Đã rời phòng và dọn dẹp sạch sẽ!');
    }

    // ── !search / !tim ────────────────────────────
    if (command === 'search' || command === 'tim') {
        const query = args.join(' ');
        if (!query) return message.reply('❌ Cú pháp: `!search <tên bài>`');
        message.channel.send(`🔍 Đang tìm **${query}**...`);
        try {
            const videos = await play.search(query, { limit: 8, source: { youtube: 'video' } });
            if (!videos.length) return message.channel.send('❌ Không tìm thấy kết quả!');
            lastSearchResults = videos;
            let msg = `🔎 **Kết quả: "${query}"**\n\n`;
            videos.forEach((v, i) => {
                msg += `\`${i+1}.\` **${v.title}**\n`;
                msg += `      👤 ${v.channel?.name || '?'}  ⏱ ${v.durationRaw || '?'}\n`;
            });
            msg += `\nGõ \`!pick <số>\` để phát hoặc \`!addall\` để thêm tất cả vào hàng đợi`;
            return message.channel.send(msg);
        } catch (e) {
            return message.channel.send(`🔴 Lỗi tìm kiếm: ${e.message}`);
        }
    }

    // ── !pick <số> ────────────────────────────────
    if (command === 'pick' || command === 'chon') {
        const idx = parseInt(args[0]) - 1;
        if (isNaN(idx) || !lastSearchResults[idx])
            return message.reply('❌ Số không hợp lệ — tìm kiếm lại bằng `!search`');
        const v   = lastSearchResults[idx];
        const res = getOrJoinVoice(message);
        if (!res) return message.reply('❌ Vào phòng voice trước!');
        queue.push({ title: v.title, url: v.url, duration: v.durationRaw, type: 'youtube' });
        if (!isPlaying) playNext(message);
        else message.reply(`✅ Đã thêm vào hàng đợi: **${v.title}** [${v.durationRaw || '?'}]`);
        return;
    }

    // ── !addall — thêm hết kết quả search vào queue ─
    if (command === 'addall') {
        if (!lastSearchResults.length) return message.reply('❌ Chưa có kết quả search!');
        const res = getOrJoinVoice(message);
        if (!res) return message.reply('❌ Vào phòng voice trước!');
        lastSearchResults.forEach(v =>
            queue.push({ title: v.title, url: v.url, duration: v.durationRaw, type: 'youtube' })
        );
        message.reply(`✅ Đã thêm ${lastSearchResults.length} bài vào hàng đợi!`);
        if (!isPlaying) playNext(message);
        return;
    }

    // ── !play / !vplay ────────────────────────────
    if (command === 'play' || command === 'vplay' || command === 'p') {
        const res = getOrJoinVoice(message);
        if (!res) return message.reply('❌ Vào phòng voice trước!');

        const attachment = message.attachments.first();
        if (attachment) {
            const ok = ['.mp3','.wav','.ogg','.m4a','.flac','.webm','.opus'];
            if (!ok.some(e => attachment.name.toLowerCase().endsWith(e)))
                return message.reply('❌ File phải là file âm thanh!');
            queue.push({ title: attachment.name, url: attachment.url, type: 'url' });
            if (!isPlaying) playNext(message);
            else message.reply(`✅ Đã thêm: **${attachment.name}**`);
            return;
        }

        const input = args.join(' ');

        // Playlist YouTube
        if (isPlaylistUrl(input)) {
            message.reply('⏳ Đang lấy thông tin playlist...');
            const cookieArg = ytdlpCookieArgs();
            const ytdlpBin = YTDLP ? `${YTDLP.cmd}${YTDLP.args.length ? ' ' + YTDLP.args.join(' ') : ''}` : 'python3 -m yt_dlp';
            const infoCmd = `${ytdlpBin} --flat-playlist --print "%(title)s|||%(webpage_url)s|||%(duration_string)s" --no-warnings ${cookieArg} "${input}" 2>/dev/null`;
            exec(infoCmd, (err, stdout) => {
                if (err || !stdout.trim()) return message.channel.send('🔴 Không lấy được playlist!');
                const lines = stdout.trim().split('\n').filter(Boolean).slice(0, 50);
                lines.forEach(line => {
                    const [title, url, dur] = line.split('|||');
                    if (title && url) queue.push({ title: title.trim(), url: url.trim(), duration: dur?.trim(), type: 'youtube' });
                });
                message.channel.send(`✅ Đã thêm **${lines.length}** bài từ playlist vào hàng đợi!`);
                if (!isPlaying) playNext(message);
            });
            return;
        }

        // Link YouTube đơn — lấy title bằng play-dl
        if (isYouTubeUrl(input)) {
            message.reply('⏳ Đang xử lý link...');
            try {
                const info  = await play.video_info(input);
                const title = info.video_details?.title || input;
                const dur   = info.video_details?.durationRaw || '';
                queue.push({ title, url: input, duration: dur, type: 'youtube' });
                if (!isPlaying) playNext(message);
                else message.channel.send(`✅ Đã thêm vào hàng đợi: **${title}**${dur ? ` [${dur}]` : ''}`);
            } catch (_) {
                // Fallback: không lấy được title, vẫn thêm vào queue
                queue.push({ title: input, url: input, type: 'youtube' });
                if (!isPlaying) playNext(message);
                else message.channel.send(`✅ Đã thêm vào hàng đợi.`);
            }
            return;
        }

        // Tên bài → tự search rồi phát
        if (input) {
            message.reply(`🔍 Tìm kiếm: **${input}**...`);
            try {
                const results = await play.search(input, { limit: 5, source: { youtube: 'video' } });
                const video   = results[0];
                if (!video) return message.channel.send('❌ Không tìm thấy bài hát!');
                queue.push({ title: video.title, url: video.url, duration: video.durationRaw, type: 'youtube' });
                if (!isPlaying) playNext(message);
                else message.channel.send(`✅ Đã thêm: **${video.title}** [${video.durationRaw || '?'}]`);
            } catch (e) { message.channel.send(`🔴 Lỗi: ${e.message}`); }
            return;
        }

        return message.reply('❌ Cú pháp: `!play <tên bài / link YT / link playlist>` hoặc đính kèm file.');
    }

    // ── !playtop <bài> — thêm vào đầu queue ──────
    if (command === 'playtop' || command === 'pt') {
        const res = getOrJoinVoice(message);
        if (!res) return message.reply('❌ Vào phòng voice trước!');
        const input = args.join(' ');
        if (!input) return message.reply('❌ Cú pháp: `!playtop <tên bài / link>`');
        message.reply(`🔍 Tìm **${input}** để thêm lên đầu...`);
        try {
            let item;
            if (isYouTubeUrl(input)) {
                item = { title: input, url: input, type: 'youtube' };
            } else {
                const results = await play.search(input, { limit: 3, source: { youtube: 'video' } });
                const video   = results[0];
                if (!video) return message.channel.send('❌ Không tìm thấy!');
                item = { title: video.title, url: video.url, duration: video.durationRaw, type: 'youtube' };
            }
            const insertIdx = isPlaying ? 1 : 0;
            queue.splice(insertIdx, 0, item);
            if (!isPlaying) playNext(message);
            else message.channel.send(`✅ Đã thêm lên đầu hàng đợi: **${item.title}**`);
        } catch (e) { message.channel.send(`🔴 Lỗi: ${e.message}`); }
        return;
    }

    // ── !replay — phát lại bài hiện tại ──────────
    if (command === 'replay' || command === 'lailai') {
        if (!player.currentUrl && queue.length === 0)
            return message.reply('❌ Không có bài nào để phát lại!');
        const current = queue[0] || (history[0] ? { ...history[0] } : null);
        if (!current) return message.reply('❌ Không có bài để phát lại!');
        if (isPlaying) {
            player.stop();
            cleanupFile(player.currentFile);
            player.currentFile = null;
            queue.unshift({ ...current });
        }
        return playNext(message);
    }

    // ── !skip ─────────────────────────────────────
    if (command === 'skip' || command === 's') {
        if (!isPlaying && queue.length === 0) return message.reply('❌ Không có bài nào đang phát!');
        const n    = Math.max(1, parseInt(args[0]) || 1);
        const skip = Math.min(n, queue.length);
        const skippedTitle = queue[0]?.title || 'bài hiện tại';
        cleanupFile(player.currentFile);
        player.currentFile = null;
        if (!player.loopMode) queue.splice(0, skip);
        player.stop();
        message.reply(`⏭️ Đã bỏ qua ${skip > 1 ? skip + ' bài' : `**${skippedTitle}**`}`);
        if (queue.length > 0) playNext(message);
        else { isPlaying = false; message.channel.send('📭 Hết hàng đợi!'); }
        return;
    }

    // ── !stop ─────────────────────────────────────
    if (command === 'stop') {
        player.stop();
        cleanupFile(player.currentFile);
        player.currentFile = null;
        queue.length = 0;
        isPlaying = false;
        player.loopMode = false;
        player.startedAt = null;
        return message.reply('⏹️ Đã dừng nhạc và xóa toàn bộ hàng đợi!');
    }

    // ── !pause / !resume ──────────────────────────
    if (command === 'pause') {
        player.pause();
        return message.reply('⏸️ Đã tạm dừng!');
    }
    if (command === 'resume' || command === 'r') {
        player.unpause();
        return message.reply('▶️ Tiếp tục phát!');
    }

    // ── !loop ─────────────────────────────────────
    if (command === 'loop' || command === 'lap') {
        player.loopMode = !player.loopMode;
        return message.reply(player.loopMode ? '🔁 Đã bật lặp bài!' : '➡️ Đã tắt lặp bài!');
    }

    // ── !autoplay ─────────────────────────────────
    if (command === 'autoplay' || command === 'ap') {
        autoplay = !autoplay;
        return message.reply(autoplay ? '✨ Autoplay bật — sẽ tự phát bài tương tự!' : '⏹️ Autoplay tắt!');
    }

    // ── !volume <0-200> ───────────────────────────
    if (command === 'volume' || command === 'vol') {
        const vol = parseInt(args[0]);
        if (isNaN(vol) || vol < 0 || vol > 200)
            return message.reply('❌ Cú pháp: `!volume <0-200>`');
        player.volume = vol;
        // Tìm resource hiện tại để set volume ngay
        try {
            const state = player.state;
            state?.resource?.volume?.setVolumeLogarithmic(vol / 100);
        } catch (_) {}
        return message.reply(`🔊 Âm lượng: **${vol}%**`);
    }

    // ── !np — bài đang phát ───────────────────────
    if (command === 'np' || command === 'nowplaying') {
        if (!player.currentTitle)
            return message.reply('❌ Không có bài nào đang phát!');
        const elapsed_ = elapsed();
        return message.reply(
            `🎵 **Đang phát:** ${player.currentTitle}\n` +
            `⏱ Đã phát: ${elapsed_}\n` +
            `🔊 Âm lượng: ${player.volume}%  |  🔁 Loop: ${player.loopMode ? '✅' : '❌'}`
        );
    }

    // ── !queue / !q ───────────────────────────────
    if (command === 'queue' || command === 'q' || command === 'danhsach') {
        const page = Math.max(0, (parseInt(args[0]) || 1) - 1);
        return message.reply(buildQueueMsg(page));
    }

    // ── !remove <số> ──────────────────────────────
    if (command === 'remove' || command === 'xoa') {
        const idx = parseInt(args[0]) - 1;
        if (isNaN(idx) || idx < 0 || idx >= queue.length)
            return message.reply('❌ Vị trí không hợp lệ!');
        const removed = queue.splice(idx, 1)[0];
        return message.reply(`🗑️ Đã xóa: **${removed.title}**`);
    }

    // ── !move <từ> <đến> ──────────────────────────
    if (command === 'move' || command === 'mv') {
        const from = parseInt(args[0]) - 1;
        const to   = parseInt(args[1]) - 1;
        if (isNaN(from) || isNaN(to) || from < 0 || to < 0 || from >= queue.length || to >= queue.length)
            return message.reply('❌ Vị trí không hợp lệ! Cú pháp: `!move <từ> <đến>`');
        const [item] = queue.splice(from, 1);
        queue.splice(to, 0, item);
        return message.reply(`↕️ Đã di chuyển **${item.title}** từ vị trí ${from+1} → ${to+1}`);
    }

    // ── !shuffle ──────────────────────────────────
    if (command === 'shuffle' || command === 'tron') {
        if (queue.length < 2) return message.reply('❌ Cần ít nhất 2 bài trong hàng đợi!');
        const start = isPlaying ? 1 : 0;
        for (let i = queue.length - 1; i > start; i--) {
            const j = Math.floor(Math.random() * (i - start + 1)) + start;
            [queue[i], queue[j]] = [queue[j], queue[i]];
        }
        return message.reply(`🔀 Đã trộn ${queue.length - start} bài!`);
    }

    // ── !clear ────────────────────────────────────
    if (command === 'clear' || command === 'xoahet') {
        const keep = isPlaying ? [queue[0]] : [];
        queue.length = 0;
        if (keep[0]) queue.push(keep[0]);
        return message.reply(isPlaying
            ? '🗑️ Đã xóa hết hàng đợi (trừ bài đang phát)!'
            : '🗑️ Đã xóa hết hàng đợi!');
    }

    // ── !history ──────────────────────────────────
    if (command === 'history' || command === 'lichsu') {
        if (!history.length) return message.reply('📭 Chưa có lịch sử phát!');
        let msg = `📜 **Lịch sử phát gần đây:**\n\n`;
        history.forEach((h, i) => {
            msg += `\`${i+1}.\` **${h.title}** — ${h.playedAt}\n`;
        });
        return message.reply(msg);
    }

    // ── !cookie — quản lý YouTube cookie ──────────
    if (command === 'cookie') {
        if (ytCookieString) {
            return message.reply(
                `✅ **YouTube cookie đang active** (${ytCookieString.length} ký tự)\n` +
                `> Dùng \`!setcookie <cookie_mới>\` để cập nhật\n` +
                `> Dùng \`!setcookie clear\` để xóa cookie`
            );
        }
        return message.reply(
            `❌ **Chưa có YouTube cookie!**\n\n` +
            `**Cách lấy cookie (chọn 1 trong 2 cách):**\n\n` +
            `**Cách 1 — Browser Console (nhanh):**\n` +
            `1. Vào https://www.youtube.com và đăng nhập\n` +
            `2. Nhấn **F12** → tab **Console**\n` +
            `3. Gõ lệnh: \`document.cookie\`\n` +
            `4. Copy toàn bộ kết quả (dòng dài)\n` +
            `5. Gõ: \`!setcookie <dán vào đây>\`\n\n` +
            `**Cách 2 — Extension (bền hơn):**\n` +
            `1. Cài extension "Get cookies.txt LOCALLY" trên Chrome\n` +
            `2. Vào youtube.com → click extension → Export\n` +
            `3. Upload file \`cookies.txt\` vào thư mục \`voice-bot/\` trên Replit`
        );
    }

    // ── !setcookie <cookie_string> ────────────────
    if (command === 'setcookie') {
        const cookieVal = args.join(' ').trim();
        if (!cookieVal) return message.reply('❌ Cú pháp: `!setcookie <cookie_string>` — Gõ `!cookie` để xem hướng dẫn.');

        if (cookieVal.toLowerCase() === 'clear') {
            ytCookieString = '';
            try { fs.unlinkSync(YT_COOKIE_FILE); } catch (_) {}
            return message.reply('🗑️ Đã xóa cookie!');
        }

        try {
            fs.writeFileSync(YT_COOKIE_FILE, cookieVal, 'utf8');
            ytCookieString = cookieVal;
            process.env.YT_COOKIE = cookieVal;
            await play.setToken({ youtube: { cookie: cookieVal } });
            return message.reply('✅ **Cookie đã được lưu và kích hoạt!**\nThử `!play <tên bài>` ngay nhé 🎵');
        } catch (e) {
            return message.reply(`🔴 Lỗi khi set cookie: ${e.message}`);
        }
    }

    // ── !vsearch <từ khóa> ────────────────────────
    if (command === 'vsearch' || command === 'vs') {
        const query = args.join(' ');
        if (!query) return message.reply('❌ Cú pháp: `!vsearch <tên video> [360|480|720|1080]`');
        message.channel.send(`🔍 Đang tìm video **${query}**...`);
        try {
            const videos = await play.search(query, { limit: 8, source: { youtube: 'video' } });
            if (!videos.length) return message.channel.send('❌ Không tìm thấy kết quả!');
            lastVSearchResults = videos;
            let msg = `📺 **Kết quả video: "${query}"**\n\n`;
            videos.forEach((v, i) => {
                msg += `\`${i + 1}.\` **${v.title}**\n`;
                msg += `      👤 ${v.channel?.name || '?'}  ⏱ ${v.durationRaw || '?'}  🔗 ${v.url}\n`;
            });
            msg += `\nGõ \`!vpick <số> [360|480|720|1080]\` để stream`;
            return message.channel.send(msg);
        } catch (e) {
            return message.channel.send(`🔴 Lỗi tìm kiếm: ${e.message}`);
        }
    }

    // ── !vpick <số> [chất lượng] ─────────────────
    if (command === 'vpick' || command === 'vp') {
        const idx = parseInt(args[0]) - 1;
        if (isNaN(idx) || !lastVSearchResults[idx])
            return message.reply('❌ Số không hợp lệ — tìm kiếm lại bằng `!vsearch`');
        const v    = lastVSearchResults[idx];
        const rawQ = (args[1] || '').replace('p', '');
        const q    = ['360','480','720','1080'].includes(rawQ) ? rawQ : '720';
        await message.reply(`📺 Đã chọn: **${v.title}** (${q}p) — đang tải...`);
        return runVStream(message, v.url, q);
    }

    // ── !vstream <url> ────────────────────────────
    if (command === 'vstream' || command === 'stream') {
        const url = args[0];
        if (!url) return message.reply(
            '❌ Cú pháp: `!vstream <link> [360|480|720|1080]`\n' +
            '🌐 Hỗ trợ: YouTube · Twitch · TikTok · Instagram · Facebook · Twitter/X · Reddit · Bilibili · Vimeo · Link .mp4/.webm trực tiếp'
        );
        const rawQ = (args[1] || '').replace('p','');
        const q    = ['360','480','720','1080'].includes(rawQ) ? rawQ : '720';
        return runVStream(message, url, q);
    }

    // ── !vqadd <url/từ khóa> [chất lượng] ─────────
    if (command === 'vqadd' || command === 'vqa') {
        if (!args[0]) return message.reply('❌ Cú pháp: `!vqadd <link hoặc từ khóa> [360|480|720|1080]`');
        const rawQ = (['360','480','720','1080'].includes(args[args.length-1]?.replace('p',''))
            ? args.pop() : '720').replace('p','');
        const q    = ['360','480','720','1080'].includes(rawQ) ? rawQ : '720';
        const input = args.join(' ');
        let url = input, title = input;

        // Nếu không phải URL → tìm kiếm
        if (!input.startsWith('http')) {
            try {
                message.channel.send(`🔍 Đang tìm **${input}**...`);
                const res = await play.search(input, { limit: 1, source: { youtube: 'video' } });
                if (!res.length) return message.channel.send('❌ Không tìm thấy video!');
                url   = res[0].url;
                title = res[0].title;
            } catch (e) {
                return message.channel.send(`🔴 Lỗi tìm kiếm: ${e.message}`);
            }
        } else {
            // Lấy tiêu đề nếu là YouTube URL
            try {
                const info = await play.video_info(url);
                title = info?.video_details?.title || url;
            } catch (_) {}
        }

        if (isStreaming) {
            videoQueue.push({ url, q, title });
            return message.channel.send(`✅ Đã thêm vào queue: **${title}** (${q}p)\n📋 Vị trí: **#${videoQueue.length}** trong hàng đợi`);
        } else {
            message.channel.send(`▶️ Không có stream nào — bắt đầu phát ngay: **${title}** (${q}p)`);
            return runVStream(message, url, q);
        }
    }

    // ── !vqlist — xem hàng đợi video ─────────────
    if (command === 'vqlist' || command === 'vql') {
        if (!videoQueue.length && !isStreaming)
            return message.reply('📋 Hàng đợi video trống! Thêm bằng `!vqadd <link/tên>`');
        let msg = `📋 **HÀNG ĐỢI VIDEO STREAM** (${videoQueue.length} video)\n`;
        if (isStreaming) msg += `\n▶️ **Đang stream:** (xem bằng Go Live)\n`;
        videoQueue.forEach((v, i) => {
            msg += `\`${i + 1}.\` **${v.title || v.url}** — ${v.q}p\n`;
        });
        if (!videoQueue.length) msg += '_Trống — thêm bằng `!vqadd`_';
        return message.channel.send(msg);
    }

    // ── !vqskip — bỏ qua video hiện tại ──────────
    if (command === 'vqskip' || command === 'vqs') {
        if (!isStreaming) return message.reply('❌ Không có stream nào đang chạy!');
        if (!videoQueue.length)
            return message.reply('⚠️ Hàng đợi trống — dùng `!vstop` để dừng hẳn.');
        const next = videoQueue[0];
        message.channel.send(`⏭️ Skip! Tiếp theo: **${next.title || next.url}** (${next.q}p)`);
        // Dừng stream hiện tại — afterStream sẽ tự phát next
        if (_currentStreamCmd) { try { _currentStreamCmd.kill('SIGKILL'); } catch(_) {} }
        return;
    }

    // ── !vqclear — xóa hàng đợi video ────────────
    if (command === 'vqclear' || command === 'vqc') {
        const n = videoQueue.length;
        videoQueue.length = 0;
        return message.reply(n > 0 ? `🗑️ Đã xóa ${n} video khỏi hàng đợi.` : '📋 Hàng đợi đã trống rồi!');
    }

    // ── !vstop / !stopstream ──────────────────────
    if (command === 'vstop' || command === 'stopstream' || command === 'ss') {
        if (!isStreaming) return message.reply('❌ Không có stream nào đang chạy!');

        // Kill ffmpeg process ngay lập tức
        if (_currentStreamCmd) {
            try { _currentStreamCmd.kill('SIGKILL'); } catch (_) {}
            _currentStreamCmd = null;
        }

        const stopChannel = _streamChannel;
        isStreaming = false;
        _streamChannel = null;

        // Stop stream + rời voice
        try {
            const streamer = await getStreamer();
            streamer.stopStream();
            await new Promise(r => setTimeout(r, 400));
            await streamer.leaveVoice();
        } catch (_) {}

        // Rejoin voice bình thường
        if (stopChannel) {
            await new Promise(r => setTimeout(r, 600));
            try {
                const vc = joinVoiceChannel({
                    channelId: stopChannel.id,
                    guildId: stopChannel.guild.id,
                    adapterCreator: stopChannel.guild.voiceAdapterCreator,
                    selfMute: false,
                    selfDeaf: false,
                });
                vc.subscribe(player);
            } catch (_) {}
        }

        return message.reply('⏹️ Đã dừng stream! Bot đã rejoin voice.');
    }

    // ── !ping ─────────────────────────────────────
    if (command === 'ping') {
        const start = Date.now();
        const msg   = await message.reply('🏓 Đang đo...');
        await msg.edit(`🏓 Pong! Độ trễ: **${Date.now() - start}ms** | WS: **${client.ws.ping}ms**`);
        return;
    }

    // ── !uptime ───────────────────────────────────
    if (command === 'uptime') {
        const secs = Math.floor(process.uptime());
        const h = Math.floor(secs / 3600);
        const m = Math.floor((secs % 3600) / 60);
        const s = secs % 60;
        return message.reply(`⏰ Uptime: **${h}h ${m}m ${s}s**`);
    }

    // ── !update ───────────────────────────────────
    if (command === 'update') {
        message.reply('⏳ Đang cập nhật yt-dlp...');
        // Thử nhiều cách cập nhật (Termux pip / system pip / python3 -m pip)
        const updateCmds = [
            'yt-dlp -U',
            'pip install -U yt-dlp',
            'pip3 install -U yt-dlp',
            'python3 -m pip install -U yt-dlp',
        ];
        const tryUpdate = (cmds) => {
            if (!cmds.length) {
                return message.channel.send('🔴 Không cập nhật được yt-dlp. Thử thủ công: `pip install -U yt-dlp`');
            }
            exec(cmds[0] + ' --quiet 2>/dev/null', (err) => {
                if (err) return tryUpdate(cmds.slice(1));
                const verCmd = YTDLP ? `${YTDLP.cmd} ${YTDLP.args.join(' ')} --version`.trim() : 'yt-dlp --version';
                exec(verCmd, (_, ver) => {
                    message.channel.send(`✅ yt-dlp đã cập nhật lên **${(ver || '?').trim()}**!`);
                });
            });
        };
        tryUpdate(updateCmds);
        return;
    }

    // ── !streamtest — test import stream lib ──────
    if (command === 'streamtest') {
        message.reply('🔍 Đang test @dank074/discord-video-stream...');
        try {
            const lib = await import('@dank074/discord-video-stream');
            const keys = Object.keys(lib).join(', ');
            return message.channel.send(
                `✅ **Stream lib load OK!**\n` +
                `📦 Exports: \`${keys}\``
            );
        } catch (e) {
            const parts = [];
            let cur = e;
            while (cur) { parts.push(cur.message || String(cur)); cur = cur.cause; }
            const fullMsg = parts.join('\n  → ');
            return message.channel.send(
                `❌ **Stream lib FAILED**\n\`\`\`\n${fullMsg.slice(0, 800)}\n\`\`\`\n` +
                `**Fix Termux:**\n` +
                `\`\`\`\ncd ~/voice-bot\nrm -rf node_modules\nnpm install --ignore-scripts\nnpm install @dank074/discord-video-stream --ignore-scripts\n\`\`\``
            );
        }
    }

    // ── !sysinfo ──────────────────────────────────
    if (command === 'sysinfo' || command === 'sys') {
        const ffmpegStatus = FFMPEG_PATH ? `✅ ${FFMPEG_PATH}` : '❌ Không tìm thấy';
        const ytdlpStatus  = YTDLP ? `✅ ${YTDLP.cmd}${YTDLP.args.length ? ' ' + YTDLP.args.join(' ') : ''}` : '❌ Không tìm thấy';
        const isTermux     = !!process.env.TERMUX_VERSION || fs.existsSync('/data/data/com.termux');
        const arch         = process.arch;
        const nodeVer      = process.version;
        const memUsed      = Math.round(process.memoryUsage().heapUsed / 1024 / 1024);
        const memTotal     = Math.round(process.memoryUsage().heapTotal / 1024 / 1024);
        return message.reply(
            `🖥️ **THÔNG TIN HỆ THỐNG**\n` +
            `━━━━━━━━━━━━━━━━━━━━━━━\n` +
            `📱 Nền tảng : ${isTermux ? 'Termux (Android)' : process.platform}\n` +
            `⚙️  Kiến trúc: ${arch}\n` +
            `🟢 Node.js  : ${nodeVer}\n` +
            `🎬 ffmpeg   : ${ffmpegStatus}\n` +
            `📥 yt-dlp   : ${ytdlpStatus}\n` +
            `📂 Temp dir : ${TMP_DIR}\n` +
            `💾 RAM dùng : ${memUsed}MB / ${memTotal}MB\n` +
            `⏰ Uptime   : ${Math.floor(process.uptime())}s`
        );
    }

    // ── !help ─────────────────────────────────────
    if (command === 'help' || command === 'huongdan') {
        const cookieStatus = ytCookieString ? '✅ Active' : '❌ Chưa set';
        const help = `
🤖 **VOICE BOT v2.2 — DANH SÁCH LỆNH**
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
**🎵 PHÁT NHẠC**
\`!play <tên/link/playlist>\` — Phát nhạc
\`!playtop <tên/link>\` — Thêm lên đầu hàng đợi
\`!search <từ khóa>\` — Tìm kiếm (8 kết quả)
\`!pick <số>\` — Phát từ kết quả tìm kiếm
\`!addall\` — Thêm tất cả kết quả vào queue
\`!replay\` — Phát lại bài hiện tại
\`!skip [số]\` — Bỏ qua 1 hoặc nhiều bài
\`!stop\` — Dừng nhạc + xóa queue
\`!pause\` / \`!resume\` — Tạm dừng / Tiếp tục
\`!loop\` — Bật/Tắt lặp bài đang phát
\`!autoplay\` — Tự phát bài tương tự khi hết queue
\`!volume <0-200>\` — Chỉnh âm lượng
\`!np\` — Bài đang phát + trạng thái

**📋 HÀNG ĐỢI**
\`!queue [trang]\` — Xem danh sách
\`!move <từ> <đến>\` — Di chuyển vị trí bài
\`!remove <số>\` — Xóa bài khỏi hàng đợi
\`!shuffle\` — Trộn ngẫu nhiên
\`!clear\` — Xóa hết hàng đợi
\`!history\` — Lịch sử phát gần đây

**📺 STREAM VIDEO (Go Live)**
\`!vsearch <tên video>\` — Tìm video để stream (8 kết quả)
\`!vpick <số> [360|480|720|1080]\` — Stream từ kết quả tìm kiếm
\`!vstream <link> [360|480|720|1080]\` — Stream trực tiếp bằng link
\`!vstop\` / \`!stopstream\` — Dừng stream hiện tại

**📋 HÀNG ĐỢI VIDEO**
\`!vqadd <link/tên> [chất lượng]\` — Thêm vào queue (tự stream nếu rảnh)
\`!vqlist\` — Xem hàng đợi video
\`!vqskip\` — Bỏ qua video hiện tại → phát tiếp theo
\`!vqclear\` — Xóa toàn bộ hàng đợi

**🔑 YOUTUBE COOKIE** (Cookie: ${cookieStatus})
\`!cookie\` — Xem trạng thái + hướng dẫn lấy cookie
\`!setcookie <cookie_string>\` — Set cookie để phát YT
\`!setcookie clear\` — Xóa cookie

**🔧 TIỆN ÍCH**
\`!join\` / \`!leave\` — Vào / Rời phòng voice
\`!ping\` — Kiểm tra độ trễ
\`!uptime\` — Thời gian bot đã chạy
\`!update\` — Cập nhật yt-dlp
\`!sysinfo\` — Xem thông tin hệ thống (ffmpeg, yt-dlp, RAM)
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━`.trim();
        return message.reply(help);
    }
});

// =============================================
//             BOT READY
// =============================================
client.on('ready', () => {
    const uptime   = new Date().toLocaleString('vi-VN');
    const isTermux = !!process.env.TERMUX_VERSION || fs.existsSync('/data/data/com.termux');
    console.log('\n═══════════════════════════════════════════');
    console.log('  🎵  VOICE BOT v2.2 — ĐÃ SẴN SÀNG!');
    console.log('═══════════════════════════════════════════');
    console.log(`  🤖  Tài khoản : ${client.user.tag}`);
    console.log(`  👑  Sếp ID    : ${ALLOWED_ID}`);
    console.log(`  🔑  Cookie YT : ${ytCookieString ? '✅ Active' : '❌ Chưa set (dùng !setcookie)'}`);
    console.log(`  🎬  ffmpeg    : ${FFMPEG_PATH ? '✅ ' + FFMPEG_PATH : '❌ Không tìm thấy — !vstream sẽ lỗi'}`);
    console.log(`  📥  yt-dlp   : ${YTDLP ? '✅ ' + YTDLP.cmd : '❌ Không tìm thấy — !vstream & playlist lỗi'}`);
    console.log(`  📂  Tmp dir  : ${TMP_DIR}`);
    console.log(`  📱  Nền tảng : ${isTermux ? 'Termux (Android) ' + process.arch : process.platform + ' ' + process.arch}`);
    console.log(`  ⌚  Khởi động : ${uptime}`);
    console.log('═══════════════════════════════════════════');
    console.log('\nLệnh: !play !search !pick !skip !stop !pause !resume');
    console.log('      !loop !autoplay !volume !queue !shuffle !history');
    console.log('      !playtop !move !replay !vstream !vstop !ping !uptime');
    console.log('      !cookie !setcookie !sysinfo\n');
    if (!FFMPEG_PATH) console.warn('[WARN] ffmpeg không tìm thấy! Termux: pkg install ffmpeg | Linux: apt install ffmpeg');
    if (!YTDLP)      console.warn('[WARN] yt-dlp không tìm thấy! Cài: pip install yt-dlp');
});

client.on('warn',  w => console.warn('[WARN]',  w));
client.on('error', e => console.error('[ERROR]', e));

client.login(USER_TOKEN);
